<section id="ClientesEn" class="bg-gray-50 py-20">
  <div class="max-w-6xl mx-auto px-6 text-center">
    <h2 class="text-3xl sm:text-6xl font-bold text-gray-900 mb-8">Our Clients</h2>
    <p class="text-gray-700 text-lg mb-6">
      We proudly serve a select clientele including executives, embassies, artists, and special delegations.
    </p>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-6 items-center justify-center">
      <img src="/clients/client1.jpeg" alt="Client 1" class="h-15 mx-auto grayscale hover:grayscale-0 transition" />
      <img src="/clients/client2.png" alt="Client 2" class="h-15 mx-auto grayscale hover:grayscale-0 transition" />
      <img src="/clients/client3.png" alt="Client 3" class="h-15 mx-auto grayscale hover:grayscale-0 transition" />
      <img src="/clients/client4.png" alt="Client 4" class="h-15 mx-auto grayscale hover:grayscale-0 transition" />
    </div>
  </div>
</section>
