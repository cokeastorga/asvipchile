<section id="about" class="py-20 bg-white text-gray-900">
  <div class="max-w-6xl mx-auto px-6 text-center">
    <h2 class="text-6xl font-bold mb-6">Sobre ASVip</h2>
    <p class="text-lg leading-relaxed">
      Somos una empresa de transporte de lujo especializada en traslados VIP para ejecutivos, embajadas, delegaciones y artistas. Nuestro equipo se compromete a ofrecer una experiencia discreta, segura y de primera clase.
    </p>
    <p class="mt-4 text-base text-gray-600">
      Con un equipo profesional bilingüe y vehículos de primera calidad, garantizamos comodidad y confiabilidad en cada viaje. Confíe en nosotros para mejorar su experiencia de viaje.
    </p>
  </div>
</section>