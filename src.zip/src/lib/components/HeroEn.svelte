<section class="relative h-screen text-white flex items-center justify-center text-center bg-black">
  <div class="absolute inset-0">
    <video autoplay muted loop playsinline class="absolute inset-0 w-full h-full object-cover opacity-100">
      <source src="/video.mp4" type="video/mp4" />
      Your browser does not support HTML5 video.
    </video>
    <div class="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent"></div>
  </div>
  <div class="relative z-10 max-w-2xl px-6 space-y-6">
    <h1 class="text-4xl md:text-8xl font-extrabold leading-tight drop-shadow-lg">
      ASVip Chile
    </h1>
    <p class="text-lg md:text-xl text-gray-200">
      Trusted by global brands, embassies, and international artists.
    </p>
    <a href="#reservar" class="inline-block bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg text-lg shadow-lg transition">
      Book Your Ride
    </a>
  </div>
</section>
