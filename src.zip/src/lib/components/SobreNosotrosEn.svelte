<section id="about" class="py-20 bg-white text-gray-900">
  <div class="max-w-6xl mx-auto px-6 text-center">
    <h2 class="text-4xl font-bold mb-6">About ASVip</h2>
    <p class="text-lg leading-relaxed">
      We are a luxury transportation company specializing in VIP transfers for executives, embassies,
      delegations, and artists. Our team is committed to offering a discreet, safe, and first-class experience.
    </p>
    <p class="mt-4 text-base text-gray-600">
      With a professional bilingual team and top-of-the-line vehicles, we ensure comfort and reliability
      throughout every journey. Trust us to elevate your travel experience.
    </p>
  </div>
</section>