<section class="py-24 bg-white text-gray-800 text-center">

 <div class="relative h-auto min-h-[600px] flex items-center justify-center text-white overflow-hidden">

  <!-- Video de fondo -->
  <video
    autoplay
    muted
    loop
    playsinline
    class="absolute top-0 left-0 w-full h-full object-cover z-0 brightness-[0.4]"
  >
    <source src="/video.mp4" type="video/mp4" />
    Your browser does not support the video tag.
  </video>

  <!-- Contenido encima del video -->
  <div class="relative z-10 w-full px-6 py-24 text-center">
    <h2 class="text-3xl md:text-6xl font-bold mb-10">Why Choose Us?</h2>

    <div class="max-w-6xl mx-auto grid md:grid-cols-3 gap-8 text-left">
      <div class="bg-white/90 text-gray-900 p-6 border rounded-lg shadow hover:shadow-lg transition">
        <h3 class="font-semibold text-lg mb-2">🚘 High-end Fleet</h3>
        <p>Modern, comfortable vehicles with executive-level amenities.</p>
      </div>
      <div class="bg-white/90 text-gray-900 p-6 border rounded-lg shadow hover:shadow-lg transition">
        <h3 class="font-semibold text-lg mb-2">🕒 Guaranteed Punctuality</h3>
        <p>Strict timing control to meet tight executive schedules.</p>
      </div>
      <div class="bg-white/90 text-gray-900 p-6 border rounded-lg shadow hover:shadow-lg transition">
        <h3 class="font-semibold text-lg mb-2">🤝 Personalized Service</h3>
        <p>24/7 availability tailored to individual requirements.</p>
      </div>
    </div>
  </div>
</div>


</section>