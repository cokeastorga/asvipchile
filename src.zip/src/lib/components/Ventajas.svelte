<section class="relative py-24 text-white text-center overflow-hidden">
  <!-- Video de fondo -->
  <video
    class="absolute inset-0 w-full h-full object-cover z-[-1]"
    autoplay
    muted
    loop
    playsinline
  >
    <source src="/video.mp4" type="video/mp4" />
    Tu navegador no soporta videos en HTML5.
  </video>

  <!-- Capa oscura opcional para mejorar contraste -->
  <div class="absolute inset-0 bg-black bg-opacity-40 z-[-1]"></div>

  <!-- Contenido -->
  <h2 class="text-6xl font-bold mb-10">¿Por qué elegirnos?</h2>
  <div class="max-w-5xl mx-auto grid md:grid-cols-3 gap-8 text-left">
    <div class="p-6 border rounded-lg shadow hover:shadow-md transition bg-white/80 text-gray-800">
      <h3 class="font-semibold text-lg mb-2">🚘 Flota de alta gama</h3>
      <p>Vehículos modernos, confortables y con todas las comodidades ejecutivas.</p>
    </div>
    <div class="p-6 border rounded-lg shadow hover:shadow-md transition bg-white/80 text-gray-800">
      <h3 class="font-semibold text-lg mb-2">🕒 Puntualidad garantizada</h3>
      <p>Control estricto de tiempos para cumplir con agendas exigentes.</p>
    </div>
    <div class="p-6 border rounded-lg shadow hover:shadow-md transition bg-white/80 text-gray-800">
      <h3 class="font-semibold text-lg mb-2">🤝 Atención personalizada</h3>
      <p>Disponibilidad 24/7 y servicio ajustado a requerimientos específicos.</p>
    </div>
  </div>
</section>
