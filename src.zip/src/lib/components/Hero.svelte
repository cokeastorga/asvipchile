<section class="relative h-screen text-white flex items-center justify-center text-center overflow-hidden">
  <!-- Video de fondo -->
  <video autoplay muted loop playsinline class="absolute inset-0 w-full h-full object-cover opacity-100">
    <source src="/video.mp4" type="video/mp4" />
    Tu navegador no soporta video HTML5.
  </video>

  <!-- Overlay oscuro -->
  <div class="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent"></div>

  <!-- Contenido del Hero -->
  <div class="relative z-10 max-w-2xl px-6 space-y-6">
    <h1 class="text-4xl md:text-8xl font-extrabold leading-tight drop-shadow-lg">
      ASvip Chile
    </h1>
    <p class="text-lg md:text-xl text-gray-200">
      Confianza, puntualidad y atención VIP para ejecutivos, embajadas y artistas.
    </p>
    <a href="#reservar" class="inline-block bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg text-lg shadow-lg transition">
      Reserva tu traslado
    </a>
  </div>
</section>
