<!-- src/lib/components/Clientes.svelte -->
<section id="clientes" class="bg-gray-50 py-20">
  <div class="max-w-6xl mx-auto px-6 text-center">
    <h2 class="text-3xl sm:text-6xl font-bold text-gray-900 mb-8">Nuestros Clientes</h2>
    <p class="text-gray-700 text-lg mb-6">
      Nos enorgullece trabajar con una clientela selecta que incluye ejecutivos, embajadas, artistas y delegaciones especiales.
    </p>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-6 items-center justify-center">
      <img src="/clients/client1.jpeg" alt="Cliente 1" class="h-15 mx-auto grayscale hover:grayscale-0 transition" />
      <img src="/clients/client2.png" alt="Cliente 2" class="h-15 mx-auto grayscale hover:grayscale-0 transition" />
      <img src="/clients/client3.png" alt="Cliente 3" class="h-16 mx-auto grayscale hover:grayscale-0 transition" />
      <img src="/clients/client4.png" alt="Cliente 4" class="h-16 mx-auto grayscale hover:grayscale-0 transition" />
    </div>
  </div>
</section>
