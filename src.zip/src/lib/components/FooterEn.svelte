<footer class="bg-black text-white py-10 px-6">
  <div class="max-w-7xl mx-auto grid gap-6 md:grid-cols-3">
    <!-- About -->
    <div>
      <h3 class="text-xl font-semibold mb-3">ASVip</h3>
      <p class="text-gray-400 text-sm">
        Premium transportation service in Chile. We specialize in VIP transfers, private tours, and personalized experiences with comfort, safety, and elegance.
      </p>
    </div>

    <!-- Links -->
    <div>
      <h3 class="text-xl font-semibold mb-3">Quick Links</h3>
      <ul class="space-y-2 text-sm">
        <li><a href="/" class="hover:text-green-400 transition">Home</a></li>
        <li><a href="#services" class="hover:text-green-400 transition">Services</a></li>
        <li><a href="#contact" class="hover:text-green-400 transition">Contact</a></li>
        <li><a href="/es" class="hover:text-green-400 transition">Español</a></li>
      </ul>
    </div>

    <!-- Contact -->
    <div>
      <h3 class="text-xl font-semibold mb-3">Contact</h3>
      <p class="text-sm text-gray-400">
        📞 +569 9641 3813<br />
        ✉️ sayala@asvipchile.cl<br />
        📍 Santiago, Chile
      </p>
    </div>
  </div>

  <div class="text-center text-sm text-gray-500 mt-10 border-t border-gray-700 pt-4">
    &copy; {new Date().getFullYear()} CC IT&Solutions. All rights reserved.
  </div>
</footer>